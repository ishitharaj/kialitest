package appstate

var GrafanaDiscoveredURL string

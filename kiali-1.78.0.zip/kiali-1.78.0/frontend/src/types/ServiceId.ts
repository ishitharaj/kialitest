export interface ServiceId {
  namespace: string;
  service: string;
}

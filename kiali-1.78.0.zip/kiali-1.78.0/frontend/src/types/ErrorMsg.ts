export type ErrorMsg = {
  title: string;
  description: string;
};

// This file is intentionally left bank.
// Kiali server may re-generate this file with configuration variables.

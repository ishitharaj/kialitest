package models

// OutboundPolicy contains information egress traffic permissions
type OutboundPolicy struct {
	Mode string `json:"mode"`
}

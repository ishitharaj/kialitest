package handlers

import (
	"net/http"
	"net/http/httptest"
	"testing"

	"github.com/gorilla/mux"
	"github.com/kiali/kiali/business"
	"github.com/kiali/kiali/business/authentication"
	"github.com/kiali/kiali/config"
	"github.com/kiali/kiali/kubernetes/kubetest"
	"k8s.io/client-go/tools/clientcmd/api"
)

func TestIstioConfigDetailsInvalidType(t *testing.T) {
	cfg := config.NewConfig()
	config.Set(cfg)
	k8s := kubetest.NewFakeK8sClient()
	business.SetupBusinessLayer(t, k8s, *cfg)

	r := mux.NewRouter()
	r.HandleFunc("/api/namespaces/ns/istio/invalid/foo", func(w http.ResponseWriter, r *http.Request) {
		ctx := authentication.SetAuthInfoContext(r.Context(), &api.AuthInfo{Token: "t"})
		IstioConfigDetails(w, r.WithContext(ctx))
	})
	ts := httptest.NewServer(r)
	defer ts.Close()

	resp, err := ts.Client().Get(ts.URL + "/api/namespaces/ns/istio/invalid/foo")
	if err != nil {
		t.Fatal(err)
	}
	if resp.StatusCode != http.StatusBadRequest {
		t.Fatalf("expected 400, got %d", resp.StatusCode)
	}
}

func TestIstioConfigPermissionsInvalidCluster(t *testing.T) {
	cfg := config.NewConfig()
	config.Set(cfg)
	k8s := kubetest.NewFakeK8sClient()
	business.SetupBusinessLayer(t, k8s, *cfg)

	req := httptest.NewRequest(http.MethodGet, "/api/istio/permissions?clusterName=nonexistent", nil)
	w := httptest.NewRecorder()
	// Handlers needs headers context to build business layer; inject a dummy auth
	r := req.WithContext(authentication.SetAuthInfoContext(req.Context(), &api.AuthInfo{Token: "t"}))
	IstioConfigPermissions(w, r)
	if w.Code != http.StatusBadRequest {
		t.Fatalf("expected 400, got %d", w.Code)
	}
}

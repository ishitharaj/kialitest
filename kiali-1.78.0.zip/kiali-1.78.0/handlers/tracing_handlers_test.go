package handlers

import (
	"net/http"
	"net/http/httptest"
	"testing"

	"github.com/kiali/kiali/config"
)

func TestGetTracingInfo_Disabled(t *testing.T) {
	cfg := config.NewConfig()
	cfg.ExternalServices.Tracing.Enabled = false
	config.Set(cfg)

	req := httptest.NewRequest(http.MethodGet, "/api/tracing/info", nil)
	w := httptest.NewRecorder()
	GetTracingInfo(w, req)
	if w.Code != http.StatusOK {
		t.Fatalf("expected 200, got %d", w.Code)
	}
}

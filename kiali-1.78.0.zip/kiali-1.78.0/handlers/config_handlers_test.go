package handlers

import (
	"net/http"
	"net/http/httptest"
	"testing"

	"github.com/kiali/kiali/config"
)

func TestConfigOK(t *testing.T) {
	cfg := config.NewConfig()
	config.Set(cfg)
	req := httptest.NewRequest(http.MethodGet, "/api/config", nil)
	w := httptest.NewRecorder()
	Config(w, req)
	if w.Code != http.StatusOK {
		t.Fatalf("expected 200, got %d", w.Code)
	}
}

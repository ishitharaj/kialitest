package handlers

import (
	"net/http"
	"net/http/httptest"
	"testing"

	"github.com/kiali/kiali/graph"
)

// Minimal test to ensure handlePanic converts graph.Response into proper error response
func TestHandlePanicGraphResponse(t *testing.T) {
	w := httptest.NewRecorder()
	func() {
		defer handlePanic(w)
		graph.Panic("bad", http.StatusBadRequest)
	}()
	if w.Code != http.StatusBadRequest {
		t.Fatalf("expected 400, got %d", w.Code)
	}
}

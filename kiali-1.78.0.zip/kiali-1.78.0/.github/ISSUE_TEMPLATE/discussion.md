---
name: Discussion
about: Some features/topics need to be discussed before we can work on it.
labels: 'discussion needed'
---

### What do you want to discuss?

### What does it improve / What problem does it solve?

### What is the recommended proposal?

### What are the alternate solutions?
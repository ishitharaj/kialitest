---
name: Dependency Upgrade
about: Upgrade a dependency in the project
labels: 'dependencies'
---

### Which dependency needs to be upgraded, and why?

### What is the current version of the dependency?

### Which version to upgrade to?

### Changelog link

Provide the dependency changelog link, if there is one available
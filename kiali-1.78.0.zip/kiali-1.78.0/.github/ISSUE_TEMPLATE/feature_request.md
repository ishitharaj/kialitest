---
name: Feature request
about: Suggest an idea for this project
title: ''
labels: 'enhancement'
assignees: ''

---

### What do you want to improve?

### What is the current behavior?

### What is the new behavior?
#!/bin/bash

echo "This script is no longer used to install Kiali. Instead, use the Kiali Operator."
echo "For more details, see https://kiali.io/docs/installation/installation-guide/"
exit 1
